#!/usr/bin/env python
# coding: utf-8

# In[33]:


import time
import numpy as np


# In[34]:


S = np.array((0,0)) #Gamescore inf format (T1,T2)
P1 = np.array((0.0,0.0,0.0)) #Player 1 with alpha1, beta1, X1
P2 = np.array((0.0,0.0,0.0)) #Player 2 with alpha2, beta2, X2
P3 = np.array((0.0,0.0,0.0)) #Player 3 with alpha3, beta3, X3
P4 = np.array((0.0,0.0,0.0)) #Player 4 with alpha4, beta4, X4
T1 = np.array((P1,P2)) #Team 1
T2 = np.array((P3,P4)) #Team 2
D = 0.1218 #average probability of a double win
sigmaA=0.05
sigmaW=0.1
sigmaD=0.02


# In[35]:


def f1(x):
    return 0.00591631*x+3.65194805


# In[36]:


def f2(x):
    return -0.00354308390*x+6.70748299


# In[37]:


def f3(x):
    return -3.87806638*10**(-11)*x**4+7.31721982*10**(-8)*x**3+ -4.95400433*10**(-5)*x**2+ 1.36745860*10**(-2)*x+3.57993197


# In[38]:


def f4(x):
    return 5.21140286*10*(-10)*x**5+7.51385614*10**(-7)*x**4+1.69471455*10**(-6)*x**3+-0.0164932045*x**2+0.248230296*x+67.7185027


# In[39]:


def bound_to(a,b,c):
    if c>=b:
        return b
    if c>=a:
        return c
    return a


# In[40]:


def riskIncrease(T1,S,w):#w soll 1 falls für Team1 sonst 2
    
    if w==1:
        owns=S[0]
        enes=S[1]
    else:
        owns=S[1]
        enes=S[0]
    a=(T1[0][0]+T1[1][0])/2
    if enes>=owns:
        d=(f1(enes-owns)-f1(0))/(f1(900)-f1(0))
    else: 
        d=0
    if d>=1:
        return 1
    if enes<=200:
        b=0
    else:
        b=0.5*(f2(1000-enes)-f2(800))/(f2(100)-f2(800))
    if owns>=100 and owns<=800:
        c=0.1*(f3(1000-owns)-f3(800))/(f3(800)-f3(250))
    else:
        c=0
    return bound_to(0,1,a+b-c+d)   


# In[41]:


def C1(T1,S): #Tichu Announcment probability for Team 1
        return bound_to(0,1,np.random.normal(riskIncrease(T1,S,1),sigmaA))
        
def C2(T2,S): #Tichu Announcment probability for Team 2
        return bound_to(0,1,np.random.normal(riskIncrease(T2,S,2),sigmaA))
        
def D1(T1,T2): #Double win probability for Team 1
        return bound_to(0,1,np.random.normal(D,sigmaD))
        
def D2(T1,T2): #Double win probability for Team 2
        return bound_to(0,1,np.random.normal(D/(1-D),sigmaD))
        
def W1(T1,S): #Tichu sucess probability for Team 1
        return bound_to(0,1,np.random.normal(f4(C1(T1,S)),sigmaW))
        
def W2(T2,S): #Tichu sucess probability for Team 2
        return bound_to(0,1,np.random.normal(f4(C2(T2,S)),sigmaW))


# In[42]:


def binaryRandomVariable(x):
    z = np.random.random(1)
    return (z <= x) 


# In[43]:


def N(): 
    mean = 1.0 
    sigma = 0.05
    return np.random.normal(mean,sigma)

def roundToNearest5(x):
    return np.around(x/5.0, decimals=0)*5
    
#where winner is either 1 or 2 depending on if T1 or T2 won
def adaptPointsDoubleWin(Zc1, Zc2, S, winner): 
    i = winner - 1
    Zc = np.array((Zc1,Zc2))

    S[i] += 200
    if Zc[i]: 
        S[i] += 100
    if Zc[(int)(not i)]: 
        S[(int)(not i)] -= 100
    
    return S


# In[44]:


def playRound(T1,T2,S):
    c1 = C1(T1,S)
    c2 = C2(T2,S)
    d1 = D1(T1,T2)
    d2 = D2(T1,T2)
    
    Zc1 = binaryRandomVariable(c1)    
    Zc2 = binaryRandomVariable(c2)

    if Zc1: print("Team 1 announces Tichu")
    if Zc2: print("Team 2 announces Tichu")
        
    Zd1 = binaryRandomVariable(d1)
    Zd2 = 0
    if not Zd1:
        d20 = d2/(1.0-d1)    
        Zd2 = binaryRandomVariable(d20)

    if Zd1: 
        adaptPointsDoubleWin(Zc1,Zc2,S,1)
        print("Team 1 does a Double-Win")
    elif Zd2: 
        adaptPointsDoubleWin(Zc1,Zc2,S,2)
        print("Team 2 does a Double-Win")
    else:
        #Add the points gained in the current round from playing
        X1, X2, X3, X4 = T1[0,2], T1[1,2], T2[0,2], T2[1,2]
        n1, n2, n3, n4, = N(), N(), N(), N()
        XT1 = n1 * X1 + n2 * X2
        XT2 = n3 * X3 + n4 * X4
        dS1 = roundToNearest5(XT1/(XT1 + XT2) * 125) - 25
        dS2 = 100 - dS1 #roundToNearest5(XT2/(XT1 + XT2) * 125) - 25
        print("Team 1 gained %d playing-points." %dS1)
        print("Team 2 gained %d playing-points." %dS2)
        print("Sum: %d" %(dS1+dS2))
        
        S[0] += dS1
        S[1] += dS2
        
        #Add the points from the Tichus
        if Zc1 and Zc2:
            w1 = W1(T1,S)
            w2 = W2(T2,S)
            w10 = w1/(w1 + w2)
            Zw10 = binaryRandomVariable(w1)
            if Zw10: 
                S[0] += 100
                S[1] -= 100
                print("Team 1 wins the Tichu-Duell.")
            else:
                S[1] += 100
                S[0] -= 100
                print("Team 2 wins the Tichu-Duell.")
              
        elif Zc1:
            w1 = W1(T1,S)
            Zw1 = binaryRandomVariable(w1)
            if Zw1: 
                S[0] += 100
                print("Team 1 wins the Tichu.")
            else:
                S[0] -= 100
                print("Team 1 loses the Tichu.")
                
        elif Zc2:
            w2 = W2(T2,S)
            Zw2 = binaryRandomVariable(w2)
            if Zw2: 
                S[1] += 100
                print("Team 2 wins the Tichu.")
            else:
                S[1] -= 100
                print("Team 2 loses the Tichu.")
    return S


# In[45]:


while(True):
    T1[0,2] = np.random.normal(0.5,0.25)
    T1[1,2] = np.random.normal(0.5,0.25)
    T2[0,2] = np.random.normal(0.5,0.25)
    T2[1,2] = np.random.normal(0.5,0.25)
    playRound(T1,T2,S)
    print("New Score (T1,T2): %d, %d \n" %(S[0],S[1]))
    time.sleep(0.15)
    if S[0] > 1000 or S[1] > 1000:
        break

