import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import fsolve

#Quadrature
def simpson(f,a,b,N):
    x, h = np.linspace(a,b, 2*N+1, retstep = True)
    return h/3.0 * (f(x[0]) + f(x[-1]) + 2*np.sum(f(x[2:-2:2])) + 4*np.sum(f(x[1:-1:2])))

#Parameters
P = 0.02208655
P2 = 0.0853
mu = 0.5

def PX(sigma):
    f = lambda x: 1.0 / (np.sqrt(2 * np.pi)*sigma) * np.exp(-1.0/2.0 * ((x - mu)/sigma)**2)
    I = simpson(f, -9, 0.9, 10000)
    
    return I + P - 1

#Solve for 0
sigma = fsolve(PX, 0.5)[0]
f = lambda x: 1.0 / (np.sqrt(2 * np.pi)*sigma) * np.exp(-1.0/2.0 * ((x - mu)/sigma)**2)

#Calculate Integral
I = simpson(f, 0, 1, 1000)

#Calculate F
F = lambda x: simpson(f, 0, x, 1000)
F2 = lambda x: 1 - F(x) - P2 

#Calculate Tichu-Border
gT = 0.9
T = fsolve(F2,0.8)

#Plot
x = np.linspace(0,1)
y = np.zeros(x.shape)

for i, xi in enumerate(x):
    y[i] = F(xi) + (1-I)/2

sigma = np.round(sigma, 3)

plt.figure()
plt.plot(x, f(x), label = r"f(X), $\mu = 0.5, \sigma = $ " + str(sigma))
plt.axvline(x = gT, ymin = 0, ymax = f(gT), color = "red", label = "Great Tichu")
plt.axvline(x = T, ymin = 0, ymax = f(T), color = "green", label = "Tichu")
plt.grid()
plt.xlabel("X")
plt.ylabel(r"$\varphi(X)$")
plt.legend()
plt.savefig("img/b0_a.png")
plt.show()

plt.figure()
plt.plot(x, y, label = "F(X)")
plt.axhline(y = 1 - P, xmin = 0.8, xmax = 0.95, color = "red", label = "Great Tichu")
plt.axhline(y = 1 - P2, xmin = 0.7, xmax = 0.85, color = "green", label = "Tichu")
plt.grid()
plt.xlabel("X")
plt.ylabel(r"$\Phi(X)$")
plt.legend()
plt.savefig("img/b0_b.png")
plt.show()

print("Mu: ", mu)
print("Sigma: ", sigma)
print("Integral f on [0,1]: ", I)
print("Tichu: ", T)

x = [0,0.5,0.5,0.5,1]
y = [1,1,0.5,0,0]

plt.figure()
plt.plot(x,y, color = "blue", label = "best answer for Player 2 (q)")
plt.plot(y,x, color = "green", label = "best answer for Player 1 (p)")
plt.xlabel("Probability p to play A")
plt.ylabel("Probability q to play A")
plt.plot([0, 0.5, 1], [1, 0.5, 0], "o", label = "nash equilibriums")
plt.grid()
plt.title("Case 1,2 - Maximum, Square Addition")
plt.legend()
plt.savefig("img/5_max")
plt.show()

x = [0,0.5,0.5,0.5,1]
y = [0,0,0.5,1,1]

plt.figure()
plt.plot(x,y, color = "blue", label = "best answer for Player 2 (q)")
plt.plot(y,x, color = "green", label = "best answer for Player 1 (p)")
plt.xlabel("Probability p to play A")
plt.ylabel("Probability q to play A")
plt.plot([0, 0.5, 1], [0, 0.5, 1], "o", label = "nash equilibriums")
plt.grid()
plt.title("Case 3 - Square Difference")
plt.legend()
plt.savefig("img/5_diff")
plt.show()

f = lambda t, k: 1 / (1 + np.exp(-k * t)*(99)) 
x = np.linspace(0,40)

plt.figure()
plt.plot(x, f(x, 0.05), label = "k = 0.05")
plt.plot(x, f(x, 0.1), label = "k = 0.1")
plt.plot(x, f(x, 0.2), label = "k = 0.2")
plt.plot(x, f(x, 0.3), label = "k = 0.3")
plt.plot(x, f(x, 0.5), label = "k = 0.5")
plt.title(r"Different logistic functions for $\beta$")
plt.grid()
plt.legend()
plt.savefig("img/5_log")
plt.show()

f= lambda t: np.abs(np.sin(4 * np.pi * t) / t) / 4.39426613065366 
F = lambda x: simpson(f, -0.25, x, 1000)

x = np.linspace(-0.25, 0.75, 1001)

plt.figure()
plt.plot(x, f(x), label = "f(X)")
plt.grid()
plt.xlabel("X")
plt.ylabel(r"$\varphi(X)$")
plt.legend()
plt.savefig("img/b1_e.png")
plt.show()


y = np.zeros(x.shape)
for i, xi in enumerate(x):
    y[i] = F(xi)

plt.figure()
plt.plot(x, y, label = "F(X)")
plt.grid()
plt.xlabel("X")
plt.ylabel(r"$\Phi(X)$")
plt.legend()
plt.savefig("img/b1_f.png")
plt.show()
