import numpy as np
import matplotlib.pyplot as plt
import Solution
import simulation

"""
Created on Tuesday June, 2nd 2020

@author: pasander, jportner, abryutkin, mschmickler

Tichu Simulation Software - Version 1.0
"""
def sim_0():
    
    alpha, beta = np.array([1,0,1,0]), np.array([1,1,1,1])
    gamma, delta = np.array([0,0,0,0]), np.array([0,0,0,0])
    maxScore, maxRounds = 1000, 40
    modes = ["normal", "professional", "equal","none", "none", "none"]

    sol = simulation.balancedGame(alpha, beta, gamma, delta, maxScore, maxRounds, modes)
    sol.plotX("img/4.1.X")
    
    set = []
    
    for k in range(10):
        set.append(simulation.balancedGame(alpha, beta, gamma, delta, maxScore, maxRounds, modes))
    
    set = Solution.SolutionSet(np.array(set))
    set.plotX("img/4.2.X")

    set = []
    modes[4] = "logistic"
    beta = np.array([0.01, 0.01, 0.01, 0.01])
    
    for k in range(10):
        set.append(simulation.balancedGame(alpha, beta, gamma, delta, maxScore, maxRounds, modes))

    set = Solution.SolutionSet(np.array(set))
    set.plotX("img/4.3.X")


def sim_1():

    for i in range(11):
        for j in range(11):
            for k in range(11):
                for l in range(11):
                
                    try:
                        Solution.loadSetfromFile("data/" + str(i)+ "_" + str(j) + "_" + str(k) + "_" + str(l) + ".npz")
                    except:
                    
                        alpha, beta = np.array([0,0,0,0]), np.array([0,0,0,0])
                        gamma, delta = np.array([0,0,0,0]), np.array([0,0,0,0])
                        maxScore, maxRounds = 1000, 40
                        modes = ["normal", "professional", "statistics","none", "none", "risk"]
                    
                        alpha = np.array([i,j,k,l]) * 0.1
                        print(str(alpha) + " was not found. Creating ...")
                        set = []
                
                        for m in range(100):
                            sol = simulation.balancedGame(alpha,beta,gamma,delta,maxScore,maxRounds, modes)
                            set.append(sol)
                            print(str(alpha) + ": " + str(m) + "%")

                        set = Solution.SolutionSet(np.array(set))
                        set.save("data/" + str(i) + "_" + str(j) +  "_" + str(k) + "_" + str(l))
                        set.save("data/" + str(j) + "_" + str(i) +  "_" + str(k) + "_" + str(l))
                        set.save("data/" + str(i) + "_" + str(j) +  "_" + str(l) + "_" + str(k))
                        set.save("data/" + str(j) + "_" + str(i) +  "_" + str(l) + "_" + str(k))
                    
                        set.switch()
                        set.save("data/" + str(k) + "_" + str(l) +  "_" + str(i) + "_" + str(j))
                        set.save("data/" + str(k) + "_" + str(l) +  "_" + str(j) + "_" + str(i))
                        set.save("data/" + str(l) + "_" + str(k) +  "_" + str(i) + "_" + str(j))
                        set.save("data/" + str(l) + "_" + str(k) +  "_" + str(j) + "_" + str(i))
                    
                        print(str(alpha) + " done.")

    print("completed simulation succesfully")
    
    
def sim_2():
    for i in range(101):
        for j in range(101):
            
            try:
                Solution.loadSetfromFile("data2/" + str(i)+ "_" + str(j) + "_" + str(50) + "_" + str(50) + ".npz")
            except:
                    
                alpha, beta = np.array([0,0,0,0]), np.array([0,0,0,0])
                gamma, delta = np.array([0,0,0,0]), np.array([0,0,0,0])
                maxScore, maxRounds = 1000, 40
                modes = ["normal", "professional", "statistics","none", "none", "risk"]
                
                alpha = np.array([i,j,50,50]) * 0.01
                print(str(alpha) + " was not found. Creating ...")
                set = []
                
                for m in range(100):
                    sol = simulation.balancedGame(alpha,beta,gamma,delta,maxScore,maxRounds, modes)
                    set.append(sol)
                    print(str(alpha) + ": " + str(m) + "%")

                set = Solution.SolutionSet(np.array(set))
                set.save("data2/" + str(i) + "_" + str(j) +  "_" + str(50) + "_" + str(50))
                set.save("data2/" + str(j) + "_" + str(i) +  "_" + str(50) + "_" + str(50))
                    
                print(str(alpha) + " done.")

    print("completed simulation succesfully")
    
def sim_3():
    for i in range(101):
        for j in range(101):
            
            try:
                Solution.loadSetfromFile("data3/" + str(i)+ "_" + str(j) + "_" + str(50) + "_" + str(50) + ".npz")
            except:
                    
                alpha, beta = np.array([0,0,0,0]), np.array([0.01,0.01,0.01,0.01])
                gamma, delta = np.array([0,0,0,0]), np.array([0,0,0,0])
                maxScore, maxRounds = 1000, 40
                modes = ["normal", "professional", "statistics","none", "logistic", "risk"]
                
                alpha = np.array([i,j,50,50]) * 0.01
                print(str(alpha) + " was not found. Creating ...")
                set = []
                
                for m in range(100):
                    sol = simulation.balancedGame(alpha,beta,gamma,delta,maxScore,maxRounds, modes)
                    set.append(sol)
                    print(str(alpha) + ": " + str(m) + "%")

                set = Solution.SolutionSet(np.array(set))
                set.save("data3/" + str(i) + "_" + str(j) +  "_" + str(50) + "_" + str(50))
                set.save("data3/" + str(j) + "_" + str(i) +  "_" + str(50) + "_" + str(50))
                    
                print(str(alpha) + " done.")

    print("completed simulation succesfully")
    
def sim_4():
    for i in range(101):
        for j in range(101):
            
            try:
                Solution.loadSetfromFile("data4/" + str(i)+ "_" + str(j) + "_" + str(50) + "_" + str(50) + ".npz")
            except:
                    
                alpha, beta = np.array([0,0,0,0]), np.array([1,1,1,1])
                gamma, delta = np.array([0,0,0,0]), np.array([0,0,0,0])
                maxScore, maxRounds = 1000, 40
                modes = ["normal", "professional", "statistics","none", "none", "risk"]
                
                alpha = np.array([i,j,50,50]) * 0.01
                print(str(alpha) + " was not found. Creating ...")
                set = []
                
                for m in range(100):
                    sol = simulation.balancedGame(alpha,beta,gamma,delta,maxScore,maxRounds, modes)
                    set.append(sol)
                    print(str(alpha) + ": " + str(m) + "%")

                set = Solution.SolutionSet(np.array(set))
                set.save("data4/" + str(i) + "_" + str(j) +  "_" + str(50) + "_" + str(50))
                set.save("data4/" + str(j) + "_" + str(i) +  "_" + str(50) + "_" + str(50))
                    
                print(str(alpha) + " done.")

    print("completed simulation succesfully")

def examples():
    
    alpha, beta = np.array([0.2,  0.8, 0.4, 0.6]), np.array([0.1,0.1,0.1,0.1])
    gamma, delta = np.array([0,0,0,0]), np.array([0,0,0,0])
    maxScore, maxRounds = 1000, 40
    modes = ["normal", "professional", "statistics","none", "logistic", "risk"]
    
    sol = simulation.balancedGame(alpha, beta, gamma, delta, maxScore, maxRounds, modes)    
    sol.plot("img/example1")
    
    set = [sol]
    for k in range(5):
        sol = simulation.balancedGame(alpha, beta, gamma, delta, maxScore, maxRounds, modes)
        set.append(sol)

    set = Solution.SolutionSet(np.array(set))
    set.plotX("img/example2")

def analyse(dataSet, name):
    
    def Z(x, y):
        set = Solution.loadSetfromFile(dataSet + str(x)+ "_" + str(y) + "_" + str(50) + "_" + str(50) + ".npz")
        wins = set.getWins()[0]
        
        if wins < 200/3 and wins > 40:
            wins2 = 50
            
        elif wins >= 200/3 :
            wins2 = 60
            
        elif wins <= 40:
            wins2 = 40
            
        return wins, wins2
    
    z = np.zeros((2,101,101))
    
    for i in range(101):
        for k in range(101):
            z[:,i,k] = Z(i,k)
            
    im = plt.imshow(z[1,:,:],cmap=plt.cm.RdBu) # drawing the function
    plt.xlabel(r"$\alpha_1$")
    plt.ylabel(r"$\alpha_2$")
    plt.title(r"Winning Games in % with $ \alpha_3 = \alpha_4 = 0.5 $")
    plt.savefig("img/simulation_" + name + "_1.png")
    plt.show()
    
    plt.imshow(z[0,:,:],cmap=plt.cm.RdBu) # drawing the function
    plt.colorbar(im)
    plt.xlabel(r"$\alpha_1$")
    plt.ylabel(r"$\alpha_2$")
    plt.title(r"Winning Games in % with $ \alpha_3 = \alpha_4 = 0.5 $")
    plt.savefig("img/simulation_" + name + "_2.png")
    plt.show()
    
    w = []
    l = []
        
    for i in range(101):
        for k in range(101):
            
            if z[0, i, k] >= 200/3 :
                w.append((i,k))
            elif z[0, i, k] <= 40 :
                l.append((i, k))
        
    w = np.array(w)
    l = np.array(l)

    plt.figure(figsize = (6.4,6.4))
    plt.plot(w[:, 0], w[:, 1], "o", label = r"$P(x) >= 0.66$")
    plt.plot(l[:, 0], l[:, 1], "o", label = r"$P(x) <= 0.4$")
    plt.xlim(-1, 101)
    plt.legend()
    plt.savefig("img/simulation_" + name + "_3.png")
    plt.show()
    
    p = lambda x: 100 - x
    t = np.linspace(0,100, 101, endpoint = True)
    
    anorm = w[:,0]**2 + w[:,1]**2
    bnorm = w[:,0] + w[:,1]
    cnorm = (100 - w[:,0])**2 + (100 - w[:,1])**2
    
    plt.figure(figsize = (6.4,6.4))
    
    for i in range(w.shape[0]):
        
        if anorm[i] <= 30**2:
            plt.plot(w[i,0], w[i,1], "oC0")
        elif anorm[i] <= 50**2 :
            plt.plot(w[i,0], w[i,1], "oC1")
        elif anorm[i] <= 70**2 :
            plt.plot(w[i,0], w[i,1], "oC2")
        elif bnorm[i] <= 100 and anorm[i] > 70**2 :
            plt.plot(w[i,0], w[i,1], "oC3")
        elif cnorm[i] <= 50**2 :    
            plt.plot(w[i,0], w[i,1], "om")
        elif cnorm[i] <= 50**2 :
            plt.plot(w[i,0], w[i,1], "oC5")
        elif cnorm[i] <= 70**2 :
            plt.plot(w[i,0], w[i,1], "oc")
        else:
            plt.plot(w[i,0], w[i,1], "oC4")
    
    plt.plot(l[:,0], l[:,1], "o", color = "gray")
    plt.plot(t, p(t), "--", color = "gray")
    plt.plot(t[:94], p(t[:94]) - 7, "-.", color = "gray")
    plt.xlim(-1, 101)
    plt.ylim(-1,101)
    plt.savefig("img/simulation_" + name + "_4.png")
    plt.show()
    
    anorm = l[:,0]**2 + l[:,1]**2
    bnorm = l[:,0] + l[:,1]
    cnorm = (100 - l[:,0])**2 + (100 - l[:,1])**2
    
    plt.figure(figsize = (6.4,6.4))
    
    for i in range(l.shape[0]):
        
        if anorm[i] <= 30**2:
            plt.plot(l[i,0], l[i,1], "oC0")
        elif anorm[i] <= 50**2 :
            plt.plot(l[i,0], l[i,1], "oC1")
        elif anorm[i] <= 70**2 :
            plt.plot(l[i,0], l[i,1], "oC2")
        elif bnorm[i] <= 100 and anorm[i] > 70**2 :
            plt.plot(l[i,0], l[i,1], "oC3")
        elif cnorm[i] <= 50**2 :    
            plt.plot(l[i,0], l[i,1], "om")
        elif cnorm[i] <= 50**2 :
            plt.plot(l[i,0], l[i,1], "oC5")
        elif cnorm[i] <= 70**2 :
            plt.plot(l[i,0], l[i,1], "oy")
        else:
            plt.plot(l[i,0], l[i,1], "oC4")
    
    plt.plot(w[:,0], w[:,1], "o", color = "gray")
    plt.plot(t, p(t), "--", color = "gray")
    plt.plot(t[:94], p(t[:94]) - 7, "-.", color = "gray")
    plt.xlim(-1, 101)
    plt.ylim(-1,101)
    plt.savefig("img/simulation_" + name + "_5.png")
    plt.show()
    
    
    
def analyse_5():
    
    a = np.zeros((1,3))
    b = np.zeros((1,3))
    c = np.zeros((1,3))
    
    for i in range(101):
        for k in range(101):
            set = Solution.loadSetfromFile("data2/" + str(i)+ "_" + str(k) + "_" + str(50) + "_" + str(50) + ".npz")
            wins = set.getWins()[0]
            if wins > 200/3 :
                a = np.append(a, np.array([i,k,wins]))
            
            
            set = Solution.loadSetfromFile("data3/" + str(i)+ "_" + str(k) + "_" + str(50) + "_" + str(50) + ".npz")
            wins = set.getWins()[0]
            if wins > 200/3 :
                b = np.append(b, np.array([i,k,wins]))
            
            set = Solution.loadSetfromFile("data4/" + str(i)+ "_" + str(k) + "_" + str(50) + "_" + str(50) + ".npz")
            wins = set.getWins()[0]
            if wins > 200/3 :
                c = np.append(c, np.array([i,k,wins]))
            
    a = a.reshape(int(a.shape[0]/3), 3)
    b = b.reshape(int(b.shape[0]/3), 3)
    c = c.reshape(int(c.shape[0]/3), 3)  
    
    p = lambda t: 100-t
    t = np.linspace(0,100)
    
    plt.figure(figsize = (6.4,6.4))
    plt.plot(a[1:, 0], a[1:, 1], "o", label = r"$\beta = 0$")
    plt.plot(b[1:, 0], b[1:, 1], "o", label = r"$\beta = logistic(t)$")
    plt.plot(c[1:, 0], c[1:, 1], "o", label = r"$\beta = 1$")
    plt.legend()
    plt.plot(t, p(t), "--", color = "gray")
    plt.xlim(-1, 101)
    plt.ylim(-1,101)
    plt.savefig("img/simulation_16.png")
    plt.show()

examples()
#analyse("data2/", "2")
#analyse("data3/", "3")
#analyse("data4/", "4")
#analyse_5()