import numpy as np
import matplotlib.pyplot as plt
import Solution
from scipy.optimize import fsolve

"""
Created on Tuesday June, 29th 2020

@author: pasander, jportner, abryutkin, mschmickler

Tichu Simulation Software - Version 1.0
"""

"""
balance

Input:  3D Array with all data
        
Output: 3D Array with all data
        
        In changed positions
"""

def balance(save):
    save[:,0,:] = Solution.switcher(save[:,0,:])
    save[:,1,:] = Solution.switcher(save[:,1,:])
    save[:,2,:] = Solution.switcher(save[:,2,:])
    save[:,3,:] = Solution.switcher2(save[:,3,:])
    save[:,4:,:] = Solution.switcher3(save[:,4:,:])
    
    return save

"""
adjusting alpha

Input:  alpha - 1D Array alpha with strategies
        delta - 1D Array delta with score and last round score
        
        (optional)
        mode - 1D Array of Strings, which adjusting shall be used.
            "none" -    no adjustments

Output: 1D Array alpha with adjusted strategies
"""

def adj_alpha(alpha, delta, mode = "none"):
    
    if mode == "none":
        return alpha
    

"""
adjusting beta

Input:  beta - 1D Array beta with information
        delta - 1D Array delta with score and last round score
        
        (optional)
        mode - 1D Array of Strings, which adjusting shall be used.
            "none" -    no adjustments
            "double" -  doubles information every round 

Output: 1D Array beta with adjusted information
"""

def adj_beta(beta, delta, mode = "none"):
    
    if mode == "none":
        return beta
    
    elif mode == "double":
        return beta*2
    
    elif mode == "logistic":
        k = 0.2
        beta = beta / (beta + (1-beta)*np.exp(-k))
        
        return beta
"""
adjusting gamma

Input:  gamma - 1D Array beta with risk
        delta - 1D Array delta with score and last round score

        (optional)
        mode - 1D Array of Strings, which adjusting shall be used.
            "none" -    no adjustments
            "risk" -    adj. according to score

Output: 1D Array gamma with adjusted risk
"""

def adj_gamma(gamma, delta, mode = "none"):
    
    if mode == "none":
        return gamma
    
    elif mode == "risk":
        
        #risk ~ difference
        def a(x):
            
            x = np.float32(x)
            
            if x <= 0:
                return 0
            
            f = lambda t: 0.00591631*t + 3.65194805
            return (f(x) - f(0)) / (f(1000) - f(0))
            
        #risk ~ enemies points
        def b(x):
            
            x = np.float32(x)
            
            if x <= 200:
                return 0
            
            f = lambda t: -0.00354308390*t + 6.70748299
            return 0.5 * (f(1000-x) - f(800)) / (f(0) - f(800))
        
        #risk ~ team points
        def c(x):
            
            x = np.float32(x)
            
            if x < 100 or x > 800:
                return 0
            
            f = lambda t: -3.87806638*10**(-11)*t**4+7.31721982*10**(-8)*t**3+ -4.95400433*10**(-5)*t**2+ 1.36745860*10**(-2)*t+3.57993197
            return 0.1 * (f(x) - f(250)) / (f(250)- f(800))

        k = 0.25
        
        gamma[0] = a(delta[1] - delta[0]) + b(delta[1]) + c(delta[0]) 
        gamma[2] = a(delta[0] - delta[1]) + b(delta[0]) + c(delta[1])
        gamma[1] = gamma[0]
        gamma[3] = gamma[2]
            
        return gamma * k
        
"""
Simulation B0

Input:  (optional)
        mode -  String, which simulation shall be used.
            "normal" - using a normal distribution
            "linear" - using a linear distribution
            
Output: 1D Array with size 4
        with random card values clipped in [0,1]
        
Variables:
        mu -    average of normal distribution
        sigma - standard deviation
        X -     1D Array with card-values
"""
def B0(mode = "none"):
    
    if mode == "none":
        return np.zeros(4)
    
    elif mode == "equal":
        return np.ones(4)*0.5
    
    elif mode == "normal":
        mu, sigma = 0.5, 0.199
    
        X = np.random.normal(mu, sigma, 4)
        X = np.clip(X, 0, 1)
        return X
    
    elif mode == "linear" :
        X = np.random.rand(4)
        return X

"""
Simulation B1

Input:  X -     1D Array with card values in [0,1]
        alpha - 1D Array with four values for strategies in [0,1]
        beta  - 1D Array with four values for information in [0,1]
        (optional)
        mode  - String, which simulation shall be used.
            "none"-         no exchange    
            "basic"-        only partners exchange, using average exchange function
            "advanced"-     exchange simulation with normal distribution
            "professional"- including receive-function
            
Output: 1D Array with size 4 with card values clipped in [0,1] after passing
        1D Array with size 4 with card values clipped in [0,1] after receiving 
        (equal to passing if no receive function used)
        
Variables:
        L -     2D Array, Lambda-Matrix (Exchange Function)
        N -     2D Array, Lambda-Matrix after Receiving
        P -     2D Array, 4 x 3, Partner, Opponents 
        mu -    average of normal distribution
        sigma - standard deviation
        z -     strategy factor 
"""

def B1(X, alpha, beta, mode = "none"):

    if mode == "none":
        return X, X

    if mode in ["basic", "advanced", "professional"]:

        L = np.eye(4)
    
        P = np.array([[1,2,3],
                      [0,2,3],
                      [3,0,1],
                      [2,0,1]])
        
        mu_p = 1.0/14.0
        sigma_p = 1.0 / 14.0
        mu_o = 0.0
        sigma_o = 1.0/28.0
        
        for i, p in enumerate(P):
            z = 1 - 2*alpha[i] + beta[i]*(2*alpha[p[0]] - 1)
            mu = mu_p + z/2*sigma_p
        
            L[i, i] = 1 - mu - 2*mu_o
            L[p[0], i] = mu
            L[p[1], i] = mu_o
            L[p[2], i] = mu_o
    
        if mode == "basic":
            X = L.dot(X)
            return np.clip(X, 0, 1), np.clip(X, 0, 1)

        for i, p in enumerate(P):
            L[i, i] = 0
            L[p[0], i] = np.random.normal(L[p[0], i], sigma_p)
            L[p[1], i] = np.random.normal(L[p[1], i], sigma_o)
            L[p[2], i] = np.random.normal(L[p[2], i], sigma_o)
            L[i, i] = 1 - sum(L[:,i])
    
        if mode == "advanced":
            X = L.dot(X)
            return np.clip(X, 0, 1), np.clip(X, 0, 1)
        
        N = L.copy()
        
        #Quadrature
        def simpson(f,a,b,N):
            x, h = np.linspace(a,b, 2*N+1, retstep = True)
            return h/3.0 * (f(x[0]) + f(x[-1]) + 2*np.sum(f(x[2:-2:2])) + 4*np.sum(f(x[1:-1:2])))
        
        #Receivefunction
        def eta(X, b):
            
            #density function with Integral 0 to infinity = 1, Integral strict monotone
            f= lambda t: np.abs(np.sin(4 * np.pi * t) / t) / 4.39426613065366 
            
            z = np.random.rand()
            z = fsolve(lambda x: simpson(f,-0.25,x,1000)-z, 1)
            
            X *= (1 + np.sign(X) * (1-b) * z) 
            
            return X
        
        for i,p in enumerate(P):
            N[p[1],i] = eta(L[p[1],i], beta[i])
            N[p[2],i] = eta(L[p[2],i], beta[i])
        
        
        if mode == "professional":
            return np.clip(L.dot(X), 0, 1), np.clip(N.dot(X), 0, 1)
    

"""
Simulation B2

Input:  X -     1D Array with card values in [0,1]
        alpha - 1D Array with four values for strategies in [0,1]
        gamma - 1D Array with four values for risk in [-1,1]
        
        (optional)
        mode  - String, which simulation shall be used.
            "none" -        no tichu, no payoff
            "equal" -       no tichu, equal payoff
            "linrandom" -   no tichu, random linear payoff
            "normrandom" -  no tichu, random normal payoff
            "teamX" -       no tichu, 100 points for selected team
            "highest" -     no tichu, winner takes it all
            "statistics" -  tichu possible, statistics
            
Output: 1D Array with size 2
        with the two team scores
        
Variables:
    
"""
def B2(X, alpha, gamma, mode = "none"):
    
    if mode == "none":
        return np.array([0,0])

    elif mode == "equal":
        return np.array([50,50])
    
    elif mode == "linrandom":
        payoff = np.random.randint(-5, 25)*5
        return np.array([payoff, 100 - payoff])
    
    elif mode == "normrandom":
        payoff = np.clip(np.round((np.random.normal(10, 5))),-5, 25) * 5
        return np.array([payoff, 100 - payoff])
    
    elif mode == "team1":
        return np.array([100,0])
    
    elif mode == "team2":
        return np.array([0,100])
    
    elif mode == "highest":
        if np.max(X[:2]) < np.max(X[2:]):
            return np.array([0,100])
        elif np.max(X[:2]) > np.max(X[2:]):
            return np.array([100,0])
        else :
            return np.zeros(2)
        
    elif mode == "statistics":
        
        #Sigmas
        s_aT, s_wT, s_P = 0.05, 0.1, 0.05
        #DoubleVictoryPercentage
        dvp = 0.1218 / 2
        
        #Probability to announce
        def annT(alpha, gamma):
            p = np.random.normal(np.clip(alpha + gamma, 0, 1), s_aT)
            p = np.clip(p,0,1)
            
            return np.array([np.average(p[:2]), np.average(p[2:])])
            
        #Probability to win with announcing probability
        def winP(x): 
            p = np.zeros(x.shape)
            p += 5.21140286*10**(-10) * np.power(x, 5) + 7.51385614*10**(-7) * np.power(x, 4) + 1.69471455*10**(-6) * np.power(x, 3) - 0.0164932045 * np.power(x, 2) + 0.248230296 * x + 67.7185027
            return p
        
        #Probability to win 
        def winT(aT):
            p = np.random.normal( winP(aT), s_wT)
            return np.clip(p, 0, 1)
            
        def winD():
            p = np.array([dvp, dvp])
            p[1] = p[1] / (1 - dvp)
            return np.clip(p, 0, 1)
        
        def true(p):
            return p >= np.random.rand()
        
        score = np.zeros(2)
        #Announcing Tichu
        aT = annT(alpha, gamma)
        announced = np.array([true(aT[0]), true(aT[1])])
        
        #Game and Points
        wD = winD()
        
        #Double Victory Team 1
        if true(wD[0]) :
            score[0] += 200
            score += announced * np.array([100, -100])
            return score
            
        #Double Victory Team 2
        elif true(wD[1]) :
            score[1] += 200
            score += announced * np.array([-100, 100])
            return score
            

        #Points
        else :
            X *= np.random.normal(1,s_P)
            p = np.sum(X[:2]) / np.sum(X)
            p = 5 * np.round(30*p) - 25
            score = np.array([p, 100-p]) 
            
        #Tichus
        wT = winT(aT)
        
        if announced[0] and announced[1]:
            
            if true(wT[0] / np.sum(wT)):
                score += announced * np.array([100, -100])    
            else :
                score += announced * np.array([-100, 100])
                
        elif announced[0]:
            
            if true(wT[0]) :
                score[0] += 100
            else :
                score[0] -= 100
            
        elif announced[1]:
            
            if true(wT[1]) :
                score[1] += 100
            else :
                score[1] -= 100
            
        return score

    
"""
Simulation B

Input:  alpha - 1D Array with four values for strategies in [0,1]
        beta  - 1D Array with four values for information in [0,1]
        gamma - 1D Array with four values for risk in [-1,1]
        delta - 1D Array with score and round score
        gameround - round in this game
        
        (optional)
        modes - 1D Array of Strings, which simulation shall be used in
        [B0, B1, B2, adj_alpha, adj_beta, adj_gamma]
        
Output: alpha - 1D Array with four values for strategies in [0,1]
        beta  - 1D Array with four values for information in [0,1] (adj.)
        gamma - 1D Array with four values for risk in [-1,1] (adj.)
        delta - 1D Array with score new round score (adj.)
        
        where (adj.) is an adjusted value after running the simulation
        
        (optional)
        X0 -    1D Array with cards before Exchange
        X1 -    1D Array with cards after Passing
        X2 -    1D Array with cards after Receiving
        
Variables:
    
"""
def B(alpha, beta, gamma, delta,
      modes = np.array(["none", "none", "none", "none", "none", "none"])):
    
    #Simulate B0    
    X0 = B0(modes[0])
    #Simulate B1
    X1, X2 = B1(X0, alpha, beta, modes[1])
    #Simulate B2
    delta[2:] = B2(X2, alpha, gamma, modes[2])
    delta[:2] += delta[2:]
    
    #adjusting alpha
    alpha = adj_alpha(alpha, delta.copy(), modes[3])
    #adjusting beta
    beta = adj_beta(beta, delta.copy(), modes[4])
    #adjusting gamma
    gamma = adj_gamma(gamma, delta.copy(), modes[5])
    
    return alpha, beta, gamma, delta, X0, X1, X2


"""
Simulation Game

Input:  alpha - 1D Array with four values for strategies in [0,1]
        beta  - 1D Array with four values for information in [0,1]
        gamma - 1D Array with four values for risk in [-1,1]
        delta - 1D Array with score and new score
        
        maxScore -     maximum Score
        maxRounds -    maximum Rounds 
        
        (optional)
        modes - 1D Array of Strings, which simulation shall be used in
        [B0, B1, B2, adj_alpha, adj_beta, adj_gamma]
        
Output: sol -   Solution with all data
        
Variables:
        save -  3D Array (Round, a b g d x0 x1, values) (N x 6 x 4)
    
"""

def Game(alpha, beta, gamma, delta, maxScore, maxRounds,
         modes = np.array(["none", "none", "none", "none", "none", "none"])):
    
    save = np.zeros((1,7,4))
    save[0,0,:] = alpha
    save[0,1,:] = beta
    save[0,2,:] = gamma
    save[0,3,:] = delta
    
    rounds = 1
    score = 0
    
    while(rounds <= maxRounds and score < maxScore):
        
        save = np.append(save.copy(), 
                         B(save[-1,0,:], save[-1,1,:],
                           save[-1,2,:], save[-1,3,:], 
                           modes)).reshape((rounds + 1, 7, 4))
        
        rounds += 1
        score = np.max(save[-1,3,:2])
        
    
    
    sol = Solution.Solution(save[:,0,:], save[:,1,:], 
                   save[:,2,:], save[:,3,:], 
                   maxScore, maxRounds, 
                   save[:,4:,:], modes)
    
    return sol


"""
Simulation Balanced Game

Input:  alpha - 1D Array with four values for strategies in [0,1]
        beta  - 1D Array with four values for information in [0,1]
        gamma - 1D Array with four values for risk in [-1,1]
        delta - 1D Array with score and new score
        
        maxScore -     maximum Score
        maxRounds -    maximum Rounds 
        
        (optional)
        modes - 1D Array of Strings, which simulation shall be used in
        [B0, B1, B2, adj_alpha, adj_beta, adj_gamma]
        
Output: sol -   Solution with all data, balanced
        
Variables:
        save -  3D Array (Round, a b g d x0 x1, values) (N x 6 x 4)
    
"""

def balancedGame(alpha, beta, gamma, delta, maxScore, maxRounds,
         modes = np.array(["none", "none", "none", "none", "none", "none"])):
    
    save = np.zeros((1,7,4))
    save[0,0,:] = alpha
    save[0,1,:] = beta
    save[0,2,:] = gamma
    save[0,3,:] = delta
    
    rounds = 1
    score = 0
    
    while(rounds <= maxRounds and score < maxScore):
        
        save = np.append(save.copy(), 
                         B(save[-1,0,:], save[-1,1,:],
                           save[-1,2,:], save[-1,3,:], 
                           modes)).reshape((rounds + 1, 7, 4))
        
        rounds += 1
        score = np.max(save[-1,3,:2])
        
        save = balance(save)
    
    sol = Solution.Solution(save[:,0,:], save[:,1,:], 
                   save[:,2,:], save[:,3,:], 
                   maxScore, maxRounds, 
                   save[:,4:,:], modes)
    
    return sol

"""
End od Definition
"""