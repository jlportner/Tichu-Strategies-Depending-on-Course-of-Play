import numpy as np
import matplotlib.pyplot as plt

def simpson(f,a,b,N):
    x, h = np.linspace(a,b, 2*N+1, retstep = True)
    return h/3.0 * (f(x[0]) + f(x[-1]) + 2*np.sum(f(x[2:-2:2])) + 4*np.sum(f(x[1:-1:2])))

"""
Pass Function Opponent
"""


mu = 0
sigma = 1.0 / 28

f = lambda x: 1.0 / (np.sqrt(2 * np.pi)*sigma) * np.exp(-1.0/2.0 * ((x - mu)/sigma)**2)
F = lambda x: simpson(f, -0.2, x, 1000)

x = np.linspace(-0.2, 0.2, 100)
y = np.zeros(x.shape)
for i,xi in enumerate(x):
    y[i] = F(xi)

plt.figure()
plt.plot(x, f(x), label = r"$\xi_O, \mu_O = 0.0, \sigma_O = 1.0/28.0$")
plt.xlabel("X")
plt.ylabel(r"$\varphi(x)$")
plt.axvline(x = 1/14, ymin = 0, ymax = 0.3, color = "orange", label = "Average Card-Value")
plt.grid()
plt.legend(loc = "upper left")
plt.savefig("b1_a.png")
plt.show()

plt.figure()
plt.plot(x, y, label = r"$\xi_O, \mu_O = 0.0, \sigma_0 = 1.0/28.0$")
plt.xlabel("X")
plt.ylabel(r"$\Phi(x)$")
plt.axhline(y = F(1/14), xmin = 0.6, xmax = 0.75, color = "orange", label = "Average Card-Value")
plt.grid()
plt.legend()
plt.savefig("b1_b.png")
plt.show()

"""
Pass Function Partner
"""


mu = 1.0/14.0
sigma = 1.0/14.0

f = lambda x: 1.0 / (np.sqrt(2 * np.pi)*sigma) * np.exp(-1.0/2.0 * ((x - mu)/sigma)**2)
F = lambda x: simpson(f, -0.2, x, 1000)

x = np.linspace(-0.2, 0.3, 100)
y = np.zeros(x.shape)
for i,xi in enumerate(x):
    y[i] = F(xi)

plt.figure()
plt.plot(x, f(x), label = r"$\xi_P, \mu_P = 1.0/14.0, \sigma_P = 1.0/14.0$")
plt.plot(x, f(x + 1/14 ), "r--", label = "z = -2")
plt.plot(x, f(x + 1/28 ), "r-.", label = "z = -1")
plt.plot(x, f(x - 1/28 ), "g-.", label = "z = 1")
plt.plot(x, f(x - 1/14 ), "g--", label = "z = 2")
plt.xlabel("X")
plt.ylabel(r"$\varphi(x)$")
plt.axvline(x = 1/14, ymin = 0, ymax = 1, color = "orange", label = "Average Card-Value")
plt.grid()
plt.legend(loc = "upper left")
plt.savefig("b1_c.png")
plt.show()

plt.figure()
plt.plot(x, y, label = r"$\xi_P, \mu_P = 1.0/14.0, \sigma_P = 1.0/14.0$")
plt.plot(x - 1/14, y, "r--", label = "z = -2")
plt.plot(x - 1/28, y, "r-.", label = "z = -1")
plt.plot(x + 1/28, y, "g-.", label = "z = 1")
plt.plot(x + 1/14, y, "g--", label = "z = 2")
plt.xlabel("X")
plt.ylabel(r"$\Phi(x)$")
plt.axvline(x = 1/14, ymin = 0, ymax = 1, color = "orange", label = "Average Card-Value")
plt.grid()
plt.legend()
plt.savefig("b1_d.png")
plt.show()