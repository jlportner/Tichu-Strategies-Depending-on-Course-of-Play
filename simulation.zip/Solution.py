import numpy as np
import matplotlib.pyplot as plt

"""
Created on Tuesday June, 2nd 2020

@author: pasander, jportner, abryutkin, mschmickler

Tichu Simulation Software - Version 1.0
"""

"""
Solution Class

Init:   alpha - 2D Array with four values for strategies in [0,1] 
        beta  - 2D Array with four values for information in [0,1] 
        gamma - 2D Array with four values for risk in [0,1]
        delta - 2D Array with score and played rounds
        x -     2D Array with card values before, while and after Exchange
        
        maxScore -     maximum Score
        maxRounds -    maximum Rounds
        
        (optional)
        modes - 1D Array of Strings, which simulation was used in
        [B0, B1, B2, adj_alpha, adj_beta, adj_gamma]
        
Functions:
        void:   
            __init__()  Initialisation
            
            switch()    Switches Team 1 and 2
    
            plot()      plots all        
            plotalpha() plots alpha
            plotbeta()  plots beta
            plotgamma() plots gamma
            plotdelta() plots delta
            plotX()     plots X
            
            save()      saves the current dataset
    
        str:    
            __str__() 
        
        np.array:
            getAlpha()  returns alpha
            getBeta()   returns beta
            getGamma()  returns gamma
            getDelta()  returns delta
            getX()      returns X
            getModes()  returns modes
            getMSMR()   returns mS and mR
    
Functions not included in class:
    
        Solution:   loadfromFile()  creates a Solution Object based on given data
"""

class Solution(object):
    
    def __init__(self, alpha, beta, gamma, delta, maxScore, maxRounds, X, modes):
        
        self._a = alpha
        self._b = beta
        self._g = gamma
        self._d = delta
        
        self._mS = maxScore
        self._mR = maxRounds
        
        self._X = X        
        self._r = X.shape[0]
        
        self._modes = modes
        
        
    """
    switch
    
    Input: None
    Output: None
    
    switches storage T1 -> T2, T2 -> T1
    """    
        
    def switch(self):
    
        self._a = switcher(self._a)
        self._b = switcher(self._b)
        self._g = switcher(self._g)
        self._d = switcher2(self._d)
        
        self._X = switcher3(self._X)
        
    """
    plot
    
    Input: name -   str how to name the output-file
    Output: None
    
    creates Plots in ./.
    """
    def plot(self, name):
        self.plotalpha(name + ".alpha")
        self.plotbeta(name + ".beta")
        self.plotgamma(name + ".gamma")
        self.plotdelta(name + ".delta")
        self.plotX(name + ".X")
    
    
    def plotalpha(self, name):
        x = np.arange(self._r)
        plt.figure()
        plt.suptitle("Settings: " + str(self._modes), y = 0.0)
        plt.plot(x, self._a[:,0], "--", label = "Player 1")
        plt.plot(x, self._a[:,1], "--", label = "Player 2")
        plt.plot(x, self._a[:,2], "--", label = "Player 3")
        plt.plot(x, self._a[:,3], "--", label = "Player 4")
        plt.xticks(x)
        plt.xlabel("rounds played")
        plt.yticks([0,1])
        plt.ylabel("strategy")
        plt.grid()
        plt.legend()
        plt.savefig(name + ".png")
        plt.show()
        
        
        
    def plotbeta(self, name):
        x = np.arange(self._r)
        plt.figure()
        plt.suptitle("Settings: " + str(self._modes), y = 0.0)
        plt.plot(x, self._b[:,0], "--", label = "Player 1")
        plt.plot(x, self._b[:,1], "--", label = "Player 2")
        plt.plot(x, self._b[:,2], "--", label = "Player 3")
        plt.plot(x, self._b[:,3], "--", label = "Player 4")
        plt.xticks(x)
        plt.xlabel("rounds played")
        plt.yticks([0,1])
        plt.ylabel("information")
        plt.grid()
        plt.legend()
        plt.savefig(name + ".png")
        plt.show()
        
    def plotgamma(self, name):    
        x = np.arange(self._r)
        
        plt.figure()
        plt.suptitle("Settings: " + str(self._modes), y = 0.0)
        plt.plot(x, self._g[:,0], "--", label = "Team 1")
        plt.plot(x, self._g[:,2], "--", label = "Team 2")
        plt.xticks(x)
        plt.xlabel("rounds played")
        plt.yticks([0,1])
        plt.ylabel("risk")
        plt.grid()
        plt.legend()
        plt.savefig(name + ".png")
        plt.show()
        
    
    def plotdelta(self, name):
        x = np.arange(self._r)
        
        fig = plt.figure(figsize = (6.4,6.4))
        gs = fig.add_gridspec(2, 1)
        ax1 = fig.add_subplot(gs[0, 0])
        ax2 = fig.add_subplot(gs[1, 0])
        
        ax1.plot(x, self._d[x,0], label = "Team 1")
        ax1.plot(x, self._d[x,1], label = "Team 2")
        ax1.set_ylabel("total score")
        ax1.set_xticks(x)
        ax1.grid()
        ax1.legend()
        
        ax2.plot(x, self._d[x,2], "o-", label = "Team 1")
        ax2.plot(x, self._d[x,3], "o-", label = "Team 2")
        ax2.set_xticks(x)
        ax2.set_ylabel("round score")
        ax2.grid()
        ax2.legend()
        
        plt.xlabel("rounds played")
        plt.suptitle("Settings: " + str(self._modes), y = 0.0)
        plt.tight_layout()
        plt.savefig(name + ".png")
        plt.show()
        
    def plotX(self, name):
        fig = plt.figure(figsize = (6.4,6.4))
        gs = fig.add_gridspec(1, 4)
        
        x = np.zeros((3,self._r-1))
        x[1, :] = 1
        x[2, :] = 2
        labels = ["B0", r"B1 $\xi$", r"B1 $\eta$"]
        
        for k in range(4):
            ax = fig.add_subplot(gs[0,k])
            ax.set_title("Player "+ str(k+1))
            
            for i in range(3):
                ax.plot(x[i],self._X[1:, i, k], "x" ,label = labels[i])
                ax.legend(loc = "upper center")
                ax.set_xlim([-0.5, 2.5])
                ax.set_ylim([-0.1, 1.2])
                ax.axhline(y = 0.78, xmin = 0.0, xmax = 1.0, color = "C3")
                ax.axhline(y = 0.9, xmin = 0.0, xmax = 1.0, color = "C4")
                ax.grid()
                
        plt.tight_layout()
        plt.suptitle("Settings: " + str(self._modes), y = 0.0)
        plt.savefig(name + ".dots.png")
        plt.show()
        
        fig = plt.figure(figsize = (6.4,6.4))
        gs = fig.add_gridspec(2, 2)
        
        for k in range(4):
            ax = fig.add_subplot(gs[int(k/2), k%2])
            ax.hist(self._X[1:,:,k], label = labels, orientation = "horizontal")
            ax.legend(loc = "best")
            ax.set_title("Player "+ str(k+1))
        
        plt.tight_layout()
        plt.suptitle("Settings: " + str(self._modes), y = 0.0)
        plt.savefig(name + ".hist.png")
        plt.show()
    
    """
    get
    
    Input: None
    Output: requested np.array
    """
    
    def getAlpha(self):
        return self._a.copy()
    
    def getBeta(self):
        return self._b.copy()
    
    def getGamma(self):
        return self._g.copy()
    
    def getDelta(self):
        return self._d.copy()
    
    def getX(self):
        return self._X.copy()
    
    def getModes(self):
        return self._modes.copy()
    
    def getMSMR(self):
        return self._mS.copy(), self._mR.copy()
    
    
    """
    save
    
    Input: name - name of the output file
    Output None
    """
    
    def save(self, filename):
        np.savez_compressed(filename, a = self._a, b = self._b, g = self._g,
                            d = self._d, X = self._X, modes = self._modes,
                            mS = self._mS, mR = self._mR)
        
        print("######################")
        print("Succesfully saved File")
        print("to " +filename + ".npz")
        print("######################")
              
    """
    str
    
    Input:  None
    Output: str - returns a valid str if called by print()
    """    

    def __str__(self):
        s =  "Score: " + str(self._d[-1,0]) + " : " + str(self._d[-1,1])
        s2 = "Played to " + str(self._mS) + " Points in max. " + str(self._mR) + " Rounds"
        return s + "\n" +  s2


"""
SolutionSet Class

Init:   solutions -     1D Array with Solution
        
Functions:
        void:   
            __init__()      Initialisation
            
            save()          saves the set of Solutions
            append()        appends the given Solution/s to the set
            appendFile()    appends the given Solutionfile to the set
            appendSetFile() appends the given SolutionSetfile to the set
            
            plotX
            
        str:    
            __str__()
            
        int:
            size()          returns number of solutions in the set
            
        Solution:
            get()           returns solution(s)
    
Functions not included in class:
    
        Solution:   loadSetfromFile()  creates a SolutionSet Object based on given data
"""

class SolutionSet(object):
    
    def __init__(self, solutions): 
        
        self._s = solutions.shape[0]
        self._solutions = solutions.copy()
    
    """
    save
    
    Input: filename - name of the output file
    Output None
    """
    
    def save(self, filename):
        np.savez_compressed(filename, sol = self._solutions)
        
        print("######################")
        print("Succesfully saved File")
        print("to " +filename + ".npz")
        print("######################")
              
    """
    switch
    
    Input: None
    Output: None
    
    switches storage T1 -> T2, T2 -> T1
    """    
        
    def switch(self):
        for k in range(self._s):
            self._solutions[k].switch()

    """
    append
    
    Input: solutions - 1D  OR filename
    Output: None
    """
    
    def append(self, solutions):
        self._solutions = np.append(self._solutions, solutions.copy())
        self._s += solutions.shape[0]
    
    def appendFile(self, filename):
        solution = loadfromFile(filename)
        self.append(np.array([solution]))
    
    ####################################################
    #                                                  #
    #       Warning! This method allows pickle         #
    #         to load objects from .npz file           #
    #                                                  #
    ####################################################
    
    def appendSetFile(self, filename):
        loaded = np.load(filename, allow_pickle = True)
        self.append(loaded["sol"])
    
    
    """
    plot
    
    Input: name - how to name the file
    Output: None
    """
    def plotX(self, name):
        
        X = self._solutions[0].getX()[1:]
        
        for x in range(1, self._s):
            X = np.append(X, self._solutions[x].getX()[1:])
        
        X = X.reshape(int(X.shape[0] / 12),3,4)
        
        fig = plt.figure(figsize = (6.4,6.4))
        gs = fig.add_gridspec(1, 4)
    
        x = np.zeros((3,X.shape[0]))
        x[1, :] = 1
        x[2, :] = 2
        labels = ["B0", r"B1 $\xi$", r"B1 $\eta$"]
        
        for k in range(4):
            ax = fig.add_subplot(gs[0,k])
            ax.set_title("Player "+ str(k+1))
            
            for i in range(3):
                ax.plot(x[i], X[:, i, k] , "x" ,label = labels[i])
                ax.legend(loc = "upper center")
                ax.set_xlim([-0.5, 2.5])
                ax.set_ylim([-0.1, 1.2])
                ax.axhline(y = 0.78, xmin = 0.0, xmax = 1.0, color = "C3")
                ax.axhline(y = 0.9, xmin = 0.0, xmax = 1.0, color = "C4")
                ax.grid()
                
        plt.tight_layout()
        plt.savefig(name + ".dots.png")
        plt.show()
        
        
        fig = plt.figure(figsize = (6.4,6.4))
        gs = fig.add_gridspec(2, 2)
        
        for k in range(4):
            ax = fig.add_subplot(gs[int(k/2), k%2])
            ax.hist(X[:,:,k], label = labels, orientation = "horizontal")
            ax.legend(loc = "best")
            ax.set_title("Player "+ str(k+1))
        
        plt.tight_layout()
        plt.savefig(name + ".hist.png")
        plt.show()
        
        
    """
    size
    
    Input: None
    Output int - number of sets
    """
    
    def size(self):
        return self._s
    
    """
    get
    
    Input: position - 1D Array which positions
    Output: 1D Array with solutions
    """
    
    def get(self, position):
        solutions = []
        
        for p in position:
            solutions.append(self._solutions[p])
        
        return np.array(solutions)
    
    def getWins(self):
        wins = np.zeros(2)
        
        for k in range(self._s):
            score = self._solutions[k].getDelta()[-1,:2]
            if score[0] > score[1] :
                wins[0] += 1
            elif score[1] > score[0] :
                wins[1] += 1
                
        return wins
    
    def getBigPlays(self):
        plays = np.zeros(2)
    
        for k in range(self._s):
            score = self._solutions[k].getDelta()[:,2:]
            
            for j in range(score.shape[0]):
                if score[j,0] > 125:
                    plays[0] += 1
                elif score[j,1] > 125:
                    plays[1] += 1
                
        return plays
    
    def getDoubleVictory(self):
        plays = np.zeros(2)
    
        for k in range(self._s):
            score = self._solutions[k].getDelta()[:,2:]
            
            for j in range(score.shape[0]):
                if score[j,0] >= 200:
                    plays[0] += 1
                elif score[j,1] >= 200:
                    plays[1] += 1
                
        return plays
    
    """
    remove
    
    Input: position - 1D Array which positions
    Output: 1D Array with solutions
    """
    
    def remove(self, position):
        pass
    
    
"""
Connected functions
"""

def loadfromFile(filename):
    loaded = np.load(filename)
    a = loaded["a"]
    b = loaded["b"]
    g = loaded["g"]
    d = loaded["d"]
    
    X = loaded["X"]
    
    modes = loaded["modes"]
    
    mR = loaded["mR"]
    mS = loaded["mS"]
    
    return Solution(a,b,g,d,mS,mR,X,modes)

####################################################
#                                                  #
#       Warning! This method allows pickle         #
#         to load objects from .npz file           #
#                                                  #
####################################################

def loadSetfromFile(filename):
    loaded = np.load(filename, allow_pickle = True)
    return SolutionSet(loaded["sol"])
    
def switcher(a):
    x = np.zeros_like(a)
    x[:, :2] = a[:, 2:]
    x[:, 2:] = a[:, :2]
    return x
        
def switcher2(a):
    x = np.zeros_like(a)
    x[:, 0] = a[:, 1]
    x[:, 1] = a[:, 0]
    x[:, 2] = a[:, 3]
    x[:, 3] = a[:, 2]
    return x
        
def switcher3(a):
    x = np.zeros_like(a)
    x[:,:, :2] = a[:, :, 2:]
    x[:,:, 2:] = a[:, :, :2]
    return x